<?php
	include_once("config.php");
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>WELCOME TO SOUTHERN JUNCTION!</title>
<meta name="description" content="WELCOME TO SOUTHERN JUNCTION!" />
<meta name="keywords" content="WELCOME TO SOUTHERN JUNCTION!" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Meta tag for IE -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<link href="css/globle.css" rel="stylesheet" type="text/css">
<link href="css/constant-contact.css" rel="stylesheet" type="text/css">
<link href="css/fonts.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">

<!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!------ Banner Script --------------->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
$(window).load(function(){
	$('.flexslider').flexslider({
		animation: "fade",	
		start: function(slider){
			slider.removeClass('flex-loading');
		}
	});
});
</script>
<style>
/*flexslider loader css*/
/*.flex-loading { height: 300px; width:100%; text-align:center; background: url(images/ajax-loader_cart.gif) no-repeat center center;}*/
</style>
</head><body>

	<div id="sitemain">

<!---- Header Start ---->
<header class="mb_header">
  <div class="container">
    <div class="logo-desktop"><a href="index.php"><img src="images/logo-desktop.png"/></a></div>
    <div class="logo-mb"><a href="index.php"><img src="images/logo-mobile.png"/></a></div>
    <div class="navigation">
      <nav class="nav-desktop"> <a class="toggleMenu" href="#"><img src="images/toogle-menu.png" alt=""></a>
        <ul class="nav nav-desktop">
          <li><a href="music-events.php" >MUSIC & <span>EVENTS</span></a></li>
          <li><a href="steakhouse-bar.php" >STEAKHOUSE <span>& BAR</span></a></li>
          <li><a href="plan-your-event.php" >PLAN YOUR <span>EVENT</span></a></li>
          <li><a href="royse-city.php" >ROYSE <span>CITY</span></a></li>
<!--           <li><a href="https://southernjunctionlive.com/irving/" >IRVING</a></li> -->
<!--           <li><a href="https://www.southernjunctionirving.org/" target="_blank">IRVING</a></li> -->
          <li><a href="contact-us.php">CONTACT</a></li>
        </ul>
      </nav>
      <nav class="nav-mb"> <a class="toggleMenu" href="#"><img src="images/toogle-menu.png" alt=""></a>
        <ul class="nav nav-desktop">
          <li><a href="index.php">Home</span></a></li>
          <li><a href="music-events.php">MUSIC & <span>EVENTS</span></a></li>
          <li><a href="steakhouse-bar.php">STEAKHOUSE <span>& BAR</span></a></li>
          <li><a href="plan-your-event.php">PLAN YOUR <span>EVENT</span></a></li>
          <li><a href="royse-city.php">ROYSE <span>CITY</span></a></li>
<!--           <li><a href="https://southernjunctionlive.com/irving/">IRVING</a></li> -->
<!--           <li><a href="https://www.southernjunctionirving.org/" target="_blank">IRVING</a></li> -->
          <li><a href="contact-us.php">CONTACT</a></li>
          <li><span class="res_tbl_mob"><a href="contact-us.php">RESERVE A TABLE</a></span></li>
          <li class="menu_social">
                        <a href="https://www.facebook.com/sojoTX/?ref=bookmarks" target="_blank"><img src="images/ftr-fb-icon.png"></a> <a href="https://www.instagram.com/southern_junction_live/" target="_blank"><img src="images/ftr-insta-icon.png"></a> <a href="https://twitter.com/SOJOTexas" target="_blank"><img src="images/ftr-twt-icon.png"></a> </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<!---- Header End ---->    <!---- Section Start ---->
    <section>
        <div class="container">
        	<!---- Banner Slider Start ---->
            <div class="banner-slider">
                <div class="flexslider flex-loading">
                    <ul class="slides">
                    	                                                
                        <li>
                        	<a href="contact-us.php">
                            	<img src="https://southernjunctionlive.com/slider_images/726170741_wedthur.png" />
                            </a>
                            <div class="caption">
                                <h1></h1>
                                <h4></h4>
                                                            </div>
                        </li>
                                                                        
                        <li>
                        	<a href="https://www.prekindle.com/promo/id/531433528378435940">
                            	<img src="https://southernjunctionlive.com/slider_images/188137848_picture6.jpg" />
                            </a>
                            <div class="caption">
                                <h1></h1>
                                <h4></h4>
                                                            </div>
                        </li>
                                                                        
                        <li>
                        	<a href="https://www.prekindle.com/promo/id/531433528055169799">
                            	<img src="https://southernjunctionlive.com/slider_images/1557029680_picture1.jpg" />
                            </a>
                            <div class="caption">
                                <h1></h1>
                                <h4></h4>
                                                            </div>
                        </li>
                                                                        
                        <li>
                        	<a href="https://www.prekindle.com/promo/id/531433528378436570">
                            	<img src="https://southernjunctionlive.com/slider_images/1604094386_picture11.jpg" />
                            </a>
                            <div class="caption">
                                <h1></h1>
                                <h4></h4>
                                                            </div>
                        </li>
                                                                        
                        <li>
                        	<a href="https://www.prekindle.com/promo/id/531433528255341340">
                            	<img src="https://southernjunctionlive.com/slider_images/1568964724_picture2.jpg" />
                            </a>
                            <div class="caption">
                                <h1></h1>
                                <h4></h4>
                                                            </div>
                        </li>
                                            </ul>
                </div>
            </div>
        	<!---- Banner Slider End ---->
            <div class="middal-section">
                <h1>Welcome to <span>Southern Junction!</span><span class="reserve-table"><a href="contact-us.php">RESERVE A TABLE</a></span></h1>
                <p>
	Howdy, y&#39;all! We bring a &quot;true&quot; Texas experience to everyone who comes through our doors. Southern Junction isn&#39;t just a live music venue and dance hall, it&#39;s also a full-fledged steakhouse. Guests can choose to cook their own steaks on the indoor grills plus enjoy other Texas-favorites from the menu while taking advantage of a full bar.</p>                <div class="cta-boxes">
                	                    <div class="boxes-main">
                        <a href="music-events.php">
                            <img src="https://southernjunctionlive.com/quicklinks_images/31188_home-cta-img1.jpg"/>
                            <div class="box-caption"><h1>LIVE MUSIC <span>& EVENTS</span></h1></div>
                            <div class="corner-top-left"></div>
                            <div class="corner-bot-left"></div>
                            <div class="corner-top-right"></div>
                            <div class="corner-bot-right"></div>
                        </a>
                    </div>
                                        <div class="boxes-main">
                        <a href="steakhouse-bar.php">
                            <img src="https://southernjunctionlive.com/quicklinks_images/5746_home-cta-img2.jpg"/>
                            <div class="box-caption"><h1>STEAKHOUSE<span>& BAR</span></h1></div>
                            <div class="corner-top-left"></div>
                            <div class="corner-bot-left"></div>
                            <div class="corner-top-right"></div>
                            <div class="corner-bot-right"></div>
                        </a>
                    </div>
                                        <div class="boxes-main">
                        <a href="plan-your-event.php">
                            <img src="https://southernjunctionlive.com/quicklinks_images/24384_home-cta-img3.jpg"/>
                            <div class="box-caption"><h1>PLAN YOUR<span>PARTY</span></h1></div>
                            <div class="corner-top-left"></div>
                            <div class="corner-bot-left"></div>
                            <div class="corner-top-right"></div>
                            <div class="corner-bot-right"></div>
                        </a>
                    </div>
                                    </div>
            </div>
        </div>
    </section>
	<!---- Section End ---->
<!---- Footer Start ---->

<footer  class = "ftr_pb">
  <div class="container">
    <div class="footer-inner">
      <div class="footer-right">
                
        <div class="social-icon">
          <div><a href="https://www.facebook.com/sojoTX/?ref=bookmarks" target="_blank"><img src="images/ftr-fb-icon.png"/></a></div>
          <div><a href="https://www.instagram.com/southern_junction_live/" target="_blank"><img src="images/ftr-insta-icon.png"/></a></div>
          <div><a href="https://twitter.com/SOJOTexas" target="_blank"twitterLink><img src="images/ftr-twt-icon.png"/></a></div>
        </div>
        <div class="newsletter">
          <h4>ReCkon YOu Join Our Newsletter!</h4>
          <script> var _ctct_m = "101e534e56b4847cdfd3f7c740238a04"; </script> 
          <input data-id="url:input" type="hidden" name="url" value="http://www.google.com">
          <script id="signupScript" src="//static.ctctcdn.com/js/signup-form-widget/current/signup-form-widget.min.js" async defer></script> 
          <div class="ctct-inline-form" data-form-id="67665ef7-bd30-4bc7-8ed9-f3ce2e3e1dd1"></div>
        </div>
      </div>
      <div class="footer-menu">
                <ul>
          <li><a href="music-events.php">Music & Events</a></li>
          <li><a href="irving.php">IRVING</a></li>
          <li><a href="steakhouse-bar.php">STEAKHOUSE & BAR</a></li>
          <li><a href="contact-us.php">CONTACT US</a></li>
          <li><a href="plan-your-event.php">PLAN YOUR EVENT</a></li>
          <li><a href="index.php" target="_blank">EMPLOYMENT</a></li>
          <li><a href="royse-city.php">ROYSE CITY</a></li>
          <li><a href="contact-us.php">GENERAL Q&A </a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!---- Footer End ---->
</div>
<style>
.ctct-inline-form .g-recaptcha {
  display: none !important
}
</style>
<script>
$(window).on('load', function() {
	//$("#email_address_1").attr("value","priyanka@sakshiinfosys.com");
	setTimeout(function(){
		//$("#email_address_1").attr("placeholder", "EMAIL");
		$('.ctct-form-footer').html("");
		$(".newsletter .g-recaptcha").html("");
		$(".ctct-form-success p.ctct-form-text").html("");
		//$( "#ctct_form_1" ).submit();
	}, 5000);
});
</script> 
<script type="text/javascript" src="js/script.js"></script>
<script>
$('.mbad-arw').click(function()
{
  	$('.mbad-bot').slideToggle('slow', function() {
   		$('.mbad-arw').toggleClass('mbad-arw-open');
   		$('.mb_tit_sub').toggleClass('mbad-tit-open');
 	});
});
</script>
</body>
</html>