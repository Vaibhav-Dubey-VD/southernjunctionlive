<?php

include_once("config.php");


if(isset($_POST['contact_message']))
{
	$firstname = mysqli_real_escape_string($con,$_POST["firstname"]);
	$lastname = mysqli_real_escape_string($con,$_POST['lastname']);
	$phone = mysqli_real_escape_string($con,$_POST['phone']);
	$email = mysqli_real_escape_string($con,$_POST['email']);
	$is_reservation = mysqli_real_escape_string($con,$_POST['is_reservation']);
	$noofpeople = mysqli_real_escape_string($con,$_POST['noofpeople']);
	$event_date = date('y-m-d',strtotime($_POST['event_date']));
	$event_time = mysqli_real_escape_string($con,$_POST['event_time']);
	$contact_message = mysqli_real_escape_string($con,$_POST['contact_message']);
	// For Newsletter
	$url = mysqli_real_escape_string($con,$_POST['url']);	
	
	$query ="INSERT INTO `sjlcontact`(`First_name`, `Last_name`, `Phone`, `Email`, `Reservation`, `No`, `Event_date`, `Event_time`, `Message`) VALUES ('".$firstname."','".$lastname."','".$phone."','".$email."','".$is_reservation."','".$noofpeople."','".$event_date."','".$event_time."','".$contact_message."')";
	
	//echo $query; die;
	
	mysqli_query($con,$query) or die(mysqli_error($con));
	
	$query1 ="INSERT INTO `sjlnewsletter`(`email`) VALUES ('".$email."')";
	mysqli_query($con,$query1) or die(mysqli_error($con));
	
	//mysqli_close($con);
	?>
    <script>
		$("#SuccessMsg").show();
	</script>
	<?php
}
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>HOWDY!</title>
<meta name="description" content="HOWDY!" />
<meta name="keywords" content="HOWDY!" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Meta tag for IE -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<link href="css/globle.css" rel="stylesheet" type="text/css">
<link href="css/constant-contact.css" rel="stylesheet" type="text/css">
<link href="css/fonts.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">

<!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!------ Banner Script --------------->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
$(window).load(function(){
	$('.flexslider').flexslider({
		animation: "fade",	
		start: function(slider){
			slider.removeClass('flex-loading');
		}
	});
});
</script>
<style>
/*flexslider loader css*/
/*.flex-loading { height: 300px; width:100%; text-align:center; background: url(images/ajax-loader_cart.gif) no-repeat center center;}*/
</style>
</head><script src="https://www.google.com/recaptcha/api.js"></script>
<script type="text/javascript" src="js/validation.js"></script>
<body>

<div id="sitemain">

<!---- Header Start ---->
<header class="mb_header">
  <div class="container">
    <div class="logo-desktop"><a href="index.html"><img src="images/logo-desktop.png"/></a></div>
    <div class="logo-mb"><a href="index.html"><img src="images/logo-mobile.png"/></a></div>
    <div class="navigation">
      <nav class="nav-desktop"> <a class="toggleMenu" href="#"><img src="images/toogle-menu.png" alt=""></a>
        <ul class="nav nav-desktop">
          <li><a href="music-events.html" >MUSIC & <span>EVENTS</span></a></li>
          <li><a href="steakhouse-bar.html" >STEAKHOUSE <span>& BAR</span></a></li>
          <li><a href="plan-your-event.php" >PLAN YOUR <span>EVENT</span></a></li>
          <li><a href="royse-city.html" >ROYSE <span>CITY</span></a></li>
<!--           <li><a href="https://southernjunctionlive.com/irving/" >IRVING</a></li> -->
<!--           <li><a href="https://www.southernjunctionirving.org/" target="_blank">IRVING</a></li> -->
          <li><a href="contact-us.php" class="act">CONTACT</a></li>
        </ul>
      </nav>
      <nav class="nav-mb"> <a class="toggleMenu" href="#"><img src="images/toogle-menu.png" alt=""></a>
        <ul class="nav nav-desktop">
          <li><a href="index.html">Home</span></a></li>
          <li><a href="music-events.html">MUSIC & <span>EVENTS</span></a></li>
          <li><a href="steakhouse-bar.html">STEAKHOUSE <span>& BAR</span></a></li>
          <li><a href="plan-your-event.html">PLAN YOUR <span>EVENT</span></a></li>
          <li><a href="royse-city.html">ROYSE <span>CITY</span></a></li>
<!--           <li><a href="https://southernjunctionlive.com/irving/">IRVING</a></li> -->
<!--           <li><a href="https://www.southernjunctionirving.org/" target="_blank">IRVING</a></li> -->
          <li><a href="contact-us.html">CONTACT</a></li>
          <li><span class="res_tbl_mob"><a href="contact-us.html">RESERVE A TABLE</a></span></li>
          <li class="menu_social">
                        <a href="https://www.facebook.com/sojoTX/?ref=bookmarks" target="_blank"><img src="images/ftr-fb-icon.png"></a> <a href="https://www.instagram.com/southern_junction_live/" target="_blank"><img src="images/ftr-insta-icon.png"></a> <a href="https://twitter.com/SOJOTexas" target="_blank"><img src="images/ftr-twt-icon.png"></a> </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<!---- Header End ---->
<!---- Section Start ---->
<section>
    <div class="container">
        <div class="contact-main">
            <div class="col-sm1 fr">
                <div class="map">
                	<!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d428972.28799805994!2d-96.97977578032406!3d32.862563721630146!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864e839fcf67acbd%3A0xee59c32ffab95853!2s101+N+Rogers+Rd%2C+Irving%2C+TX+75061%2C+USA!5e0!3m2!1sen!2sin!4v1519130280163" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>-->
                	<div id="map_wrapper">
                        <div id="map_canvas" class="mapping"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm1 fl">
                <h1>HOWDY!</h1>
                <div class="page-content"><p><p>
	Check out all the headliners to <a href="https://www.prekindle.com/search/s/Southern%20Junction">purchase tickets</a>. Phone number and address below. Feel free to fill out our Reserve/Contact form below to make your reservations or ask a question. Texas. Lives. Here.</p></p></div>
                <div class="city-address fl">
                                        <h6>ROYSE CITY</h6>
                    <p>
                        <a href="https://goo.gl/maps/G27wBrq9m8H2" target="_blank">5574 TX-276<br />
Royse City, TX 75189</a>
                        <a href="tel:972.771.2418">972.771.2418</a>
                    </p>
                    <p>Mon - Tue: Closed<br />
Wed: 6pm - 12am<br />
Thur - Sat: 6pm - 2am<br />
Sun: Closed</p>
                </div>                
            </div>
            <div class="contact-form-main" id="reserve">
                <h4>RESERVE / CONTACT</h4>	
                <p><p>
	Please fill out all fields and someone will reply ASAP</p></p>
                
                <div class="reserve-form">
                <div id="LoadingIcon" style="display:none; position:absolute;top:0;left:0;width:100%;height:100%; background-color:rgba(255,255,255,0.3);z-index:9999; text-align:center; padding-top:70%;"><img src="images/ajax-loader.gif" /></div>
                    
                    <form name="ContactForm" id="ContactForm" method="post">
                        <ul>
                            <li>
                                <div class="col-sm2"><input name="firstname" id="firstname" placeholder="First Name" type="text"></div>
                                <div class="col-sm2 fr"><input name="lastname" id="lastname" placeholder="Last Name" type="text"></div>
                            </li>
                            <li>
                                <div class="col-sm2"><input name="phone" id="phone" placeholder="Phone" type="text"></div>
                                <div class="col-sm2 fr"><input name="email" id="email" placeholder="Email" type="text"></div>
                            </li>
                            <li>
                                <div class="col-sm1">
                                    <span class="reserve-lab">Is This a Reservation?</span>
                                    <label class="control control--radio margin-right14">Yes
                                      	<input name="is_reservation" id="is_reservation" value="Yes" type="radio" checked>
                                      	<div class="control__indicator"></div>
                                    </label>
                                    <label class="control control--radio">No
                                    	<input name="is_reservation" id="is_reservation" value="No" type="radio">
                                      	<div class="control__indicator"></div>
                                    </label>
                                </div>
                               <div id="resevation_yes">
                                    <div class="col-sm1 margin-rl">
                                     <input type="hidden" name="location_yes" id="location_yes" value="Royse City" />
                                        <div class="col-sm2-sm1 fl">
                                            <select name="noofpeople" id="noofpeople">
                                                <option value=""># of People</option>
                                                                                                <option value="1">1</option>
                                                                                                <option value="2">2</option>
                                                                                                <option value="3">3</option>
                                                                                                <option value="4">4</option>
                                                                                                <option value="5">5</option>
                                                                                                <option value="6">6</option>
                                                                                                <option value="7">7</option>
                                                                                                <option value="8">8</option>
                                                                                                <option value="9">9</option>
                                                                                                <option value="10">10</option>
                                                                                                <option value="11">11</option>
                                                                                                <option value="12">12</option>
                                                                                                <option value="13">13</option>
                                                                                                <option value="14">14</option>
                                                                                                <option value="15">15</option>
                                                                                                <option value="16">16</option>
                                                                                                <option value="17">17</option>
                                                                                                <option value="18">18</option>
                                                                                                <option value="19">19</option>
                                                                                                <option value="20">20</option>
                                                                                            </select>
                                        </div>
                                        <div class="col-sm2-sm1 fr">
                                            <input id="event_date" name="event_date" type="text" placeholder="Event Date">
                                        </div>
                                    </div>
                                    <div class="col-sm1 no-marging">
                                        <div class="col-sm2 fl" style="width:35%">
                                            <select name="event_time" id="event_time" >
                                                                                                <option value="6:00pm">6:00pm</option>
                                                                                                <option value="6:15pm">6:15pm</option>
                                                                                                <option value="6:30pm">6:30pm</option>
                                                                                                <option value="6:45pm">6:45pm</option>
                                                                                                <option value="7:00pm">7:00pm</option>
                                                                                                <option value="7:15pm">7:15pm</option>
                                                                                                <option value="7:30pm">7:30pm</option>
                                                                                                <option value="7:45pm">7:45pm</option>
                                                                                                <option value="8:00pm">8:00pm</option>
                                                                                                <option value="8:15pm">8:15pm</option>
                                                                                                <option value="8:30pm">8:30pm</option>
                                                                                                <option value="8:45pm">8:45pm</option>
                                                                                                <option value="9:00pm">9:00pm</option>
                                                                                            </select>
                                        </div>
                                        <div class="col-sm2-sm fr" style="width:58%">
                                            <select name="newsletter1" id="newsletter1" onChange="return setCaptchaDisplay(this.value);">
                                                <option value="">Join Newsletter</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                            </li>
                            <li style="display:none;" id="resevation_no">
                                <div class="col-sm1"><input name="contact_subject" id="contact_subject" placeholder="Subject" type="text"></div>
                                <div class="col-sm1 margin-rl">
                                     <select name="newsletter2" id="newsletter2" onChange="return setCaptchaDisplay(this.value);">
                                        <option value="">Join Newsletter</option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                    </select>
                                </div>
                            </li>
                            <li>
                                <div class="col-sm-full"><textarea name="contact_message" id="contact_message" placeholder="Message"></textarea></div>
                                <div class="send-captch">                        	                            
                                    <div class="captcha-img" id="captchaDisplay">
                                    	<div class="g-recaptcha" data-sitekey="6LfjNEYgAAAAALaO4tPsEo8QZH6u9TIo5sJEYjvT" style="transform:scale(0.90);-webkit-transform:scale(0.90);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>
                                    </div>
                                    <div class="submit-button">
                                        <input type="hidden" name="reserve_hid" id="reserve_hid" value="1">
<input name="btnContacForm" id="btnContacForm" value="Submit" type="button" onClick="return chkContactForm();">
                                    </div>
                                </div>
                                <div id="newsletterProcessMsg" class="SuccessMsg" style="margin-top:10px;"></div>
                                <div class="SuccessMsg" id="SuccessMsg" style="display:none; margin-top:10px;">Request has been successfully submitted.</div>
                            </li>
                        </ul>
                    </form>
                </div>                    
            </div>
            <div class="aq_main">
                <h4>GENERAL Q&A </h4>
                <ul class="aq_list">
                		
                    <li>
                        <h5>Q: HOW DO I MAKE A RESERVATION?</h5>
                        <p>A: You do not have to make a reservation for dinner. However, we recommend you do so for parties of 4 or more and on weekend nights. If there is a headlining act, and you're coming for dinner, we HIGHLY recommend making a reservation. Fill out the form above.</p>
                    </li>
                    	
                    <li>
                        <h5>Q: IS THERE A COVER FEE?</h5>
                        <p>A: Cover varies each night. <a href= "https://www.prekindle.com/search/s/Southern%20Junction">View full calendar </a> for both locations to see pricing. Or you can navigate to your location of choice and see the full calendar for cover prices and any specials. Early Bird specials often include free cover.</p>
                    </li>
                    	
                    <li>
                        <h5>Q: WHAT IS THE DRESS CODE?</h5>
                        <p>A: No sleeveless shirts on men. Pants must be worn around the waist (no sagging). Boots, Jeans and Cowboys hats encouraged!</p>
                    </li>
                    	
                    <li>
                        <h5>Q: WHAT IS THE AGE POLICY?</h5>
                        <p>A: A: 16 years of age & under must be accompanied by their own parent or legal guardian. (17 and under must be out by 11pm). 18-20 are allowed in with someone that is over 21 but you must be 21+ to drink. 19 & 20 are allowed in by themselves with a valid ID after 11pm. Age limits and Requirements are subject to change during special events and concerts. Everyone must have a valid form of ID to enter our establishment. No admittance without valid photo ID. Call Southern Junction for age limits set for each concert.</p>
                    </li>
                                    </ul>
            </div>
        </div>
    </div>
</section>
<!---- Section End ---->
<!---- Footer Start ---->

<footer >
  <div class="container">
    <div class="footer-inner">
      <div class="footer-right">
                
        <div class="social-icon">
          <div><a href="https://www.facebook.com/sojoTX/?ref=bookmarks" target="_blank"><img src="images/ftr-fb-icon.png"/></a></div>
          <div><a href="https://www.instagram.com/southern_junction_live/" target="_blank"><img src="images/ftr-insta-icon.png"/></a></div>
          <div><a href="https://twitter.com/SOJOTexas" target="_blank"twitterLink><img src="images/ftr-twt-icon.png"/></a></div>
        </div>
        <div class="newsletter">
          <h4>ReCkon YOu Join Our Newsletter!</h4>
          <input name="url" id="url" placeholder="Email" type="email">
          <input name="Submit1" id="Submit1" value="Submit" type="button" onClick="return newsletter();" >
          <script>function newsletter()
            {         
              $("#url").hide();
              $("#Submit1").hide();
                document.write("Thank You For Joining Newsletter");

            }
            </script>
          <script> var _ctct_m = "101e534e56b4847cdfd3f7c740238a04"; </script> 
          <input data-id="url:input" type="hidden" name="url" value="http://www.google.com">
          <script id="signupScript" src="//static.ctctcdn.com/js/signup-form-widget/current/signup-form-widget.min.js" async defer></script> 
          <div class="ctct-inline-form" data-form-id="67665ef7-bd30-4bc7-8ed9-f3ce2e3e1dd1"></div>
        </div>
      </div>
      <div class="footer-menu">
                <ul>
          <li><a href="music-events.php">Music & Events</a></li>
          <li><a href="irving.php">IRVING</a></li>
          <li><a href="steakhouse-bar.php">STEAKHOUSE & BAR</a></li>
          <li><a href="contact-us.php">CONTACT US</a></li>
          <li><a href="plan-your-event.php">PLAN YOUR EVENT</a></li>
          <li><a href="index.php" target="_blank">EMPLOYMENT</a></li>
          <li><a href="royse-city.php">ROYSE CITY</a></li>
          <li><a href="contact-us.php">GENERAL Q&A </a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!---- Footer End ---->
</div>
<style>
.ctct-inline-form .g-recaptcha {
  display: none !important
}
</style>
<script>
$(window).on('load', function() {
	//$("#email_address_1").attr("value","priyanka@sakshiinfosys.com");
	setTimeout(function(){
		//$("#email_address_1").attr("placeholder", "EMAIL");
		$('.ctct-form-footer').html("");
		$(".newsletter .g-recaptcha").html("");
		$(".ctct-form-success p.ctct-form-text").html("");
		//$( "#ctct_form_1" ).submit();
	}, 5000);
});
</script> 
<script type="text/javascript" src="js/script.js"></script>

<script>
function setCaptchaDisplay(va){
	//alert(va);
	if(va == 'Yes'){
		$("#captchaDisplay").hide();
	}
	else{
		$("#captchaDisplay").show();
	}
}
function chkContactForm()
{
	var err = "";
	var firstname = $("#firstname").val();
	var lastname = $("#lastname").val();
	var email = $("#email").val();
	var phone = $("#phone").val();
	var noofpeople = $("#noofpeople").val();
	var event_date = $("#event_date").val();
	var event_time = $("#event_time").val();
	var contact_message = $("#contact_message").val();
	var contact_subject = $("#contact_subject").val();
	var is_reservation = $("#is_reservation").val();
	//var newsletter1 = $("#newsletter1").val();
	
	
	var newsletter1 = $("#newsletter1").val();
	var newsletter2 = $("#newsletter2").val();
	
	var v = grecaptcha.getResponse();
	
	if($('input[name=is_reservation]:checked').val() == "Yes")
	{
		var location_yes = $("#location_yes").val();
		
		if(firstname==""){
			err+= "First Name is required.\n";
		}
		if(lastname==""){
			err+= "Last Name is required.\n";
		}
		if(phone==""){
			err+= "Phone is required.\n";
		}
		if(email==""){
			err+= "Email is required.\n";
		}
		else if(!emailInvalid(email))
		{
			err +="Email is invalid.\n";
		}		
		if(location_yes==""){
			err+= "Location is required.\n";
		}
	}
	else
	{
		var location_no = $("#location_no").val();
		
		if(email==""){
			err+= "Email is required.\n";
		}
		else if(!emailInvalid(email))
		{
			err +="Email is invalid.\n";
		}	
		if(location_no==""){
			err+= "Location is required.\n";
		}
	}
		
	if(newsletter1 == 'No' || newsletter2 == 'No'){
		if(v.length == 0)
		{
			err+= "reCaptcha is required.\n";
		}
	}
	if(err!=""){
		alert(err);
		return false;
	}
	else
	{
		//alert("i m going to submit");
		$("#ContactForm").submit();
		return true;	
	}
	
	
}
</script>
<link rel="stylesheet" href="css/datepicker.css">
<script src="js/datepicker.js"></script>
<script> 
$( function() {
    $( "#event_date" ).datepicker();
});

$(function(){
  	$('input[name=is_reservation]').click(function(){
		$("#contact_message").val("");
    	if ($(this).is(':checked'))
    	{
    		if($(this).val() == "No")
			{
				$("#resevation_no").show();
				$("#resevation_yes").hide();
			}
			else
			{
				$("#resevation_yes").show();
				$("#resevation_no").hide();
			}
    	}
  	});
});
</script>

<!--<script src="https://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAGGGuQugOwO9E6Ukh6dx3Hg6AStO5XsgY&sensor=false" type="text/javascript"></script>  
<script type="text/javascript">
    var locations = [
     ['Royse City', 32.9013808, -96.3650739, 1]
    ];
	
	var infoWindowContent = [
        ['<div class="info_content">' + '<h4>Royse City</h4>' + '<p>5574 TX-276, Royse City, TX 75189</p>' + '</div>']
    ];
		
	var bounds = new google.maps.LatLngBounds();
	
    var map = new google.maps.Map(document.getElementById('map_canvas'), {
      mapTypeId: google.maps.MapTypeId.ROADMAP,
	  gestureHandling: 'greedy',
	  styles: [
            {elementType: 'geometry', stylers: [{color: '#2d2d2d'}]},
            {elementType: 'labels.text.stroke', stylers: [{color: '#242f3e'}]},
            {elementType: 'labels.text.fill', stylers: [{color: '#746855'}]},
            
            {
              featureType: 'poi.park',
              elementType: 'geometry',
              stylers: [{color: '#2d2d2d'}]
            },
            
            {
              featureType: 'road',
              elementType: 'geometry',
              stylers: [{color: '#191715'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry.stroke',
              stylers: [{color: '#212a37'}]
            },
            {
              featureType: 'road',
              elementType: 'labels.text.fill',
              stylers: [{color: '#9ca5b3'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry',
              stylers: [{color: '#4c4646'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry.stroke',
              stylers: [{color: '#1f2835'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'labels.text.fill',
              stylers: [{color: '#f3d19c'}]
            },
            {
              featureType: 'transit',
              elementType: 'geometry',
              stylers: [{color: '#3f3f3f'}]
            },
            {
              featureType: 'transit.station',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'water',
              elementType: 'geometry',
              stylers: [{color: '#3f3f3f'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.fill',
              stylers: [{color: '#515c6d'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.stroke',
              stylers: [{color: '#3f3f3f'}]
            }
          ]

    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {
		var position = new google.maps.LatLng(locations[i][1], locations[i][2]);
		// 
		//if(i==0){var mrkrImg = "marker.png"; var markerSize = "45,48";}else{var mrkrImg = "marker2.png"; var markerSize = "72,30";}
		if(i==0){
			var markerIcon = new google.maps.MarkerImage("images/marker.png", null, null, null, new google.maps.Size(45,48));
		}else{
			var markerIcon = new google.maps.MarkerImage("images/marker2.png", null, null, null, new google.maps.Size(72,30));
		}
      	marker = new google.maps.Marker({
			position: position,
			map: map,
            title: locations[i][0],
			icon: markerIcon
		});
		bounds.extend(position);
		
      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(infoWindowContent[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
	  map.fitBounds(bounds);
    }
	
	var listener = google.maps.event.addListener(map, "idle", function () {
		map.setZoom(9);
		google.maps.event.removeListener(listener);
	})
</script>
</body>
</html>