// JavaScript Document
function emailInvalid(s)
{
	if(!(s.match(/^[\w]+([_|\.-][\w]{1,})*@[\w]{1,}([_|-|\.-][\w]{1,})*\.([a-z]{2,4})$/i)) )
    {
		return false;
	}
	else
	{
		return true;
	}
}
function chkreservationFrm()
{
	var err = "";
	var firstname = $("#firstname").val();
	var lastname = $("#lastname").val();
	var email = $("#email").val();
	var event_type = $("#event_type").val();
	var event_date = $("#event_date").val();
	var event_location = $("#event_location").val();
	var v = grecaptcha.getResponse();
	
	if(firstname==""){
		err+= "First Name is required.\n";
	}
	if(lastname==""){
		err+= "Last Name is required.\n";
	}
	if(email==""){
		err+= "Email is required.\n";
	}
	else if(!emailInvalid(email))
	{
		err +="Email is invalid.\n";
	}
	if(event_type==""){
		err+= "Event Type is required.\n";
	}
	if(event_date==""){
		err+= "Event Date is required.\n";
	}
	if($('input[name=event_location]:checked').length<=0){
		err+= "Location is required.\n";
	}
    if(v.length == 0){
		err+= "reCaptcha is required.\n";
    }
	
	if(err!=""){
		alert(err);
		return false;
	}
	else{
		return true;
	}	
}

