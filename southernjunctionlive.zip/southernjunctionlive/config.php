<?php

session_start();
error_reporting(E_ERROR); 

$con = mysqli_connect("localhost","root","","southernjunctionlive");

if(mysqli_connect_errno()) 
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

?>