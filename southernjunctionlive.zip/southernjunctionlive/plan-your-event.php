<?php
include_once("config.php");


if($_POST['EventFormSubmit'])
{
	// For Plan Your Event
	$firstname = mysqli_real_escape_string($_POST['firstname']);
	$lastname = mysqli_real_escape_string($_POST['lastname']);
	$email = mysqli_real_escape_string($_POST['email']);
	$event_type = mysqli_real_escape_string($_POST['event_type']);
	$event_date = mysqli_real_escape_string(date('y-m-d',strtotime($_POST['event_date'])));
	$reserve_details = mysqli_real_escape_string($_POST['reserve_details']);
	
	$query2 ="INSERT INTO `sjlplanyourevent`(`First_name`, `Last_name`, `Email`, `Event_type`, `Event_time
	`, `Details`) VALUES ('$firstname','$lastname','$email','$event_type','$event_date','$reserve_details');";
	
	mysqli_query($con,$query2) or die(mysqli_error($con));
	
	mysqli_close($con);
}
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Plan your Event at SOJO</title>
<meta name="description" content="Plan your Event at SOJO" />
<meta name="keywords" content="Plan your Event at SOJO" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Meta tag for IE -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<link href="css/globle.css" rel="stylesheet" type="text/css">
<link href="css/constant-contact.css" rel="stylesheet" type="text/css">
<link href="css/fonts.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">

<!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!------ Banner Script --------------->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
$(window).load(function(){
	$('.flexslider').flexslider({
		animation: "fade",	
		start: function(slider){
			slider.removeClass('flex-loading');
		}
	});
});
</script>
<style>
/*flexslider loader css*/
/*.flex-loading { height: 300px; width:100%; text-align:center; background: url(https://southernjunctionlive.com/images/ajax-loader_cart.gif) no-repeat center center;}*/
</style>
</head><script src="https://www.google.com/recaptcha/api.js" async defer></script>

<body>
	<div id="sitemain">

<!---- Header Start ---->
<header class="mb_header">
  <div class="container">
    <div class="logo-desktop"><a href="index.html"><img src="images/logo-desktop.png"/></a></div>
    <div class="logo-mb"><a href="index.html"><img src="images/logo-mobile.png"/></a></div>
    <div class="navigation">
      <nav class="nav-desktop"> <a class="toggleMenu" href="#"><img src="images/toogle-menu.png" alt=""></a>
        <ul class="nav nav-desktop">
          <li><a href="music-events.html" >MUSIC & <span>EVENTS</span></a></li>
          <li><a href="steakhouse-bar.html" >STEAKHOUSE <span>& BAR</span></a></li>
          <li><a href="plan-your-event.html" class="act">PLAN YOUR <span>EVENT</span></a></li>
          <li><a href="royse-city.html" >ROYSE <span>CITY</span></a></li>
<!--           <li><a href="https://southernjunctionlive.com/irving/" >IRVING</a></li> -->
<!--           <li><a href="https://www.southernjunctionirving.org/" target="_blank">IRVING</a></li> -->
          <li><a href="contact-us.html" >CONTACT</a></li>
        </ul>
      </nav>
      <nav class="nav-mb"> <a class="toggleMenu" href="#"><img src="images/toogle-menu.png" alt=""></a>
        <ul class="nav nav-desktop">
          <li><a href="index.html">Home</span></a></li>
          <li><a href="music-events.html">MUSIC & <span>EVENTS</span></a></li>
          <li><a href="steakhouse-bar.html">STEAKHOUSE <span>& BAR</span></a></li>
          <li><a href="plan-your-event.html">PLAN YOUR <span>EVENT</span></a></li>
          <li><a href="royse-city.html">ROYSE <span>CITY</span></a></li>
<!--           <li><a href="https://southernjunctionlive.com/irving/">IRVING</a></li> -->
<!--           <li><a href="https://www.southernjunctionirving.org/" target="_blank">IRVING</a></li> -->
          <li><a href="contact-us.html">CONTACT</a></li>
          <li><span class="res_tbl_mob"><a href="contact-us.html">RESERVE A TABLE</a></span></li>
          <li class="menu_social">
                        <a href="https://www.facebook.com/sojoTX/?ref=bookmarks" target="_blank"><img src="images/ftr-fb-icon.png"></a> <a href="https://www.instagram.com/southern_junction_live/" target="_blank"><img wsrc="images/ftr-insta-icon.png"></a> <a href="https://twitter.com/SOJOTexas" target="_blank"><img src="images/ftr-twt-icon.png"></a> </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<!---- Header End ---->	<!---- Section Start ---->
    <section>
    	<div class="container">
        	<div class="plan-event">
                <h1>Plan your Event at SOJO</h1>
                <p>
	Need a place to kick up your heels &amp; enjoy the best live Country Music in the Metroplex? For over 25 years, Southern Junction&#39;s Royse City location has been bringing legends like Merle Haggard, Randy Rogers, Mark Chesnutt, Josh Abbott and more.</p>
<p>
	Huge dance floor, grill your own steaks, full bar and enough room for a party as big as Dallas!</p>                <div class="plan-view">
                    <ul class="plan-subnav menu-desktop">
                    	                        <li><a href="#weddings" class="active">Weddings</a></li>
                                                <li><a href="#corporate-events" class="">Corporate Events</a></li>
                                                <li><a href="#large-parties" class="">Large Parties</a></li>
                                                <li><a href="#holiday" class="">Holiday</a></li>
                                                <li><a href="#vip-experience" class="">VIP Experience</a></li>
                                                <li><a href="#reserve">RESERVE</a></li>
                    </ul>
                    <!--for Mobile large-->
                    <div class="plan-event-mobile">
                        <ul class="plan-subnav-mobile">
                                                        <li><a href="#weddings" class="active">Weddings</a></li>
                                                        <li><a href="#corporate-events" class="">Corporate Events</a></li>
                                                        <li><a href="#large-parties" class="">Large Parties</a></li>
                            </ul><ul class="plan-subnav-mobile">                            <li><a href="#holiday" class="">Holiday</a></li>
                                                        <li><a href="#vip-experience" class="">VIP Experience</a></li>
                                                        <li><a href="#reserve">RESERVE</a></li>
                        </ul>
                    </div>
                    <!-- / for Mobile large-->
                    
                    <!--for Mobile small-->
                    <div class="plan-event-mobile-sm">
                        <ul class="plan-subnav-mobile-sm">
                                                        <li><a href="#weddings" class="active">Weddings</a></li>
                                                        <li><a href="#corporate-events" class="">Corporate Events</a></li>
                            </ul><ul class="plan-subnav-mobile-sm">                            <li><a href="#large-parties" class="">Large Parties</a></li>
                                                        <li><a href="#holiday" class="">Holiday</a></li>
                            </ul><ul class="plan-subnav-mobile-sm">                            <li><a href="#vip-experience" class="">VIP Experience</a></li>
                                                        <li><a href="#reserve">RESERVE</a></li>
                        </ul>
                    </div>
                    <!-- / for Mobile small-->
                    
                    
                                        <div id="weddings" class="type-of-event">
                        <h2>Weddings</h2>
                        <img class="img-right" src="https://southernjunctionlive.com/plan_events/1601010603_eventimageswedding.jpg"/>
                        <p>From engagement parties to rehearsal dinners to the Main Event, our event planning staff can offer full catering, entertainment and a menu that's customized to fit your needs.

<br> Royse City location has seating for up to 500 and capacity of 1500</p>
                    </div>
                                        <div id="corporate-events" class="type-of-event">
                        <h2>Corporate Events</h2>
                        <img class="img-left" src="https://southernjunctionlive.com/plan_events/321929578_eventimagescorp.jpg"/>
                        <p>Create lasting impressions for your next corporate event! We bring a true Texas experience to your meeting, company outing or client entertainment. Need help creating a one-of-a-kind company party or gala? Our experts work with you to make lasting memories and exceed your expectations!</p>
                    </div>
                                        <div id="large-parties" class="type-of-event">
                        <h2>Large Parties</h2>
                        <img class="img-right" src="https://southernjunctionlive.com/plan_events/1414_plan-type3.jpg"/>
                        <p>Family reunions, Alumni reunions, or even celebrating a milestone in your life? When you need to find a place to eat, drink, dance and bring a big posse of your folks, SoJo is a perfect fit! You don't have to rent out the entire space to accommodate a fun, memorable party.</p>
                    </div>
                                        <div id="holiday" class="type-of-event">
                        <h2>Holiday</h2>
                        <img class="img-left" src="https://southernjunctionlive.com/plan_events/426829110_eventimagesholiday.jpg"/>
                        <p>Company Holiday parties do NOT need to be a boring, same-old occasion. Celebrate the Season like a true Texan by bringing your holiday party to SoJo! Large or small, there's nothing like having your team kick back with Texas' finest food, drinks and music!</p>
                    </div>
                                        <div id="vip-experience" class="type-of-event">
                        <h2>VIP Experience</h2>
                        <img class="img-right" src="https://southernjunctionlive.com/plan_events/29714_plan-type5.jpg"/>
                        <p>It doesn't get any more Texan than this! Our Irving location has a special VIP area right above the Ballroom Bar with an uninterrupted view of the dance floor and stage. A designated server, pre-planned meals, drink service and more awaits you and up to 5 guests who need that extra level of service.</p>
                    </div>
                                        <div id="reserve" class="reserve-event">
                        <h4>Reserve Your Event</h4>	
                        <p>
	Fill out the form below and one of our event specialists will contact you shortly to book your event</p>                        <div class="reserve-form">
                        	                        	<form name="reservationFrm" id="reservationFrm" method="post">
                                <ul>
                                    <li>
                                        <div class="col-sm1"><input name="firstname" id="firstname" type="text" placeholder="First Name"></div>
                                        <div class="col-sm1 margin-rl"><input name="lastname" id="lastname" type="text" placeholder="Last Name"></div>
                                        <div class="col-sm1"><input name="email" id="email" type="text" placeholder="Email"></div>
                                    </li>
                                    <li>
                                        <div class="col-sm1">
                                            <select name="event_type" id="event_type">
                                                <option value="">Event Type</option>
                                                                                                <option value="Weddings">Weddings</option>
                                                                                                <option value="Corporate Events">Corporate Events</option>
                                                                                                <option value="Large Parties">Large Parties</option>
                                                                                                <option value="Holiday">Holiday</option>
                                                                                                <option value="VIP Experience">VIP Experience</option>
                                                                                            </select>
                                        </div>
                                        <div class="col-sm1 margin-rl"><input id="event_date" name="event_date" type="text" placeholder="Event Date"></div>
                                        <!--<div class="col-sm1">
                                            <label class="control control--radio">Royse City
                                              <input type="radio" name="event_location" value="Royse City"/>
                                              <div class="control__indicator"></div>
                                            </label>
                                            <label class="control control--radio">Irving
                                              <input type="radio" name="event_location" value="Irving"/>
                                              <div class="control__indicator"></div>
                                            </label>
                                        </div>-->
                                    </li>
                                    <li>
                                        <div class="col-sm-full"><textarea name="reserve_details" id="reserve_details" placeholder="Details"></textarea></div>
                                        <div class="send-captch">                        	                            
                                            <div class="captcha-img">
                                            	<!--<img src="https://southernjunctionlive.com/images/captcha-img.png"/>-->
                                                <div class="g-recaptcha" data-theme="light" data-sitekey="6LfjNEYgAAAAALaO4tPsEo8QZH6u9TIo5sJEYjvT" style="transform:scale(0.90);-webkit-transform:scale(0.90);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>
                                            </div>
                                            <input type="hidden" name="reserve_hid" id="reserve_hid" value="1">
                                            <div class="submit-button"><input name="EventFormSubmit" id="EventFormSubmit" type="submit" value="Submit" onClick=" return chkreservationFrm();"></div>
                                        </div>
                                    </li>
                                </ul>
                            </form>
                        </div>
                        <div class="aq_main">
                            <h4>EVENT Q&A </h4>
                            <ul class="aq_list">
                            	                                <li>
                                    <h5>Q: HOW DO I RESERVE AN EVENT?</h5>
                                    <p>A: You can either fill out the form above or call the specific location to schedule a tour, appointment or phone meeting.</p>
                                </li>
                                                                <li>
                                    <h5>Q: WHAT IF I WANT TO RESERVE A PARTY DURING A HEADLINING CONCERT?</h5>
                                    <p>A: Call or fill out the form above at the EARLIEST opportunity to ensure we can reserve for your full party. We can work out exactly what you want to include with your party (tickets, food, drink, area) and take care of everything for you.</p>
                                </li>
                                                                <li>
                                    <h5>Q: CAN I BRING MY OWN FOOD AND DRINK?</h5>
                                    <p>A: No, as a licensed venue, Texas law states all alcoholic beverages must go through the venue and no outside drinks can be brought inside. Our chef can help you create a catering menu for your events as well. You are welcome to bring in cake or other bakery items to celebrate a birthday, wedding, anniversary, etc.</p>
                                </li>
                                                                <li>
                                    <h5>Q: WHAT IS INCLUDED WITH OUR EVENT?</h5>
                                    <p>A: Each event held here is customized to fit your needs and budget. Whether you want a fully, all-inclusive event for a charity benefit or you just want to reserve a large table, we work with you to ensure we do as much (or as little) as necessary for your success.</p>
                                </li>
                                                            </ul>
                        </div>
                    </div>
                </div>
            </div>
    	</div>
    </section>
	<!---- Section End ---->

<!---- Footer Start ---->

<footer >
  <div class="container">
    <div class="footer-inner">
      <div class="footer-right">
                
        <div class="social-icon">
          <div><a href="https://www.facebook.com/sojoTX/?ref=bookmarks" target="_blank"><img src="images/ftr-fb-icon.png"/></a></div>
          <div><a href="https://www.instagram.com/southern_junction_live/" target="_blank"><img src="images/ftr-insta-icon.png"/></a></div>
          <div><a href="https://twitter.com/SOJOTexas" target="_blank"twitterLink><img src="images/ftr-twt-icon.png"/></a></div>
        </div>
        <div class="newsletter">
          <h4>ReCkon YOu Join Our Newsletter!</h4>
          <script> var _ctct_m = "101e534e56b4847cdfd3f7c740238a04"; </script> 
          <input data-id="url:input" type="hidden" name="url" value="http://www.google.com">
          <script id="signupScript" src="//static.ctctcdn.com/js/signup-form-widget/current/signup-form-widget.min.js" async defer></script> 
          <div class="ctct-inline-form" data-form-id="67665ef7-bd30-4bc7-8ed9-f3ce2e3e1dd1"></div>
        </div>
      </div>
      <div class="footer-menu">
                <ul>
          <li><a href="music-events.php">Music & Events</a></li>
          <li><a href="irving.php">IRVING</a></li>
          <li><a href="steakhouse-bar.php">STEAKHOUSE & BAR</a></li>
          <li><a href="contact-us.php">CONTACT US</a></li>
          <li><a href="plan-your-event.php">PLAN YOUR EVENT</a></li>
          <li><a href="index.php" target="_blank">EMPLOYMENT</a></li>
          <li><a href="royse-city.php">ROYSE CITY</a></li>
          <li><a href="contact-us.php">GENERAL Q&A </a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!---- Footer End ---->
</div>
<style>
.ctct-inline-form .g-recaptcha {
  display: none !important
}
</style>
<script>
$(window).on('load', function() {
	//$("#email_address_1").attr("value","priyanka@sakshiinfosys.com");
	setTimeout(function(){
		//$("#email_address_1").attr("placeholder", "EMAIL");
		$('.ctct-form-footer').html("");
		$(".newsletter .g-recaptcha").html("");
		$(".ctct-form-success p.ctct-form-text").html("");
		//$( "#ctct_form_1" ).submit();
	}, 5000);
});
</script>
<script>
  function setCaptchaDisplay(va){
  	//alert(va);
	if(va == 'Yes'){
		$("#captchaDisplay").hide();
	}
	else{
		$("#captchaDisplay").show();}

    var v = grecaptcha.getResponse();
  }
 	if($('input[name=is_reservation]:checked').val() == "Yes")
 	{
		var location_yes = $("#location_yes").val();
  }
</script> 
<script type="text/javascript" src="js/script.js"></script>
<link rel="stylesheet" href="css/datepicker.css">
<script src="js/datepicker.js"></script>
<script> 
$( function() {
    $( "#event_date" ).datepicker();
});
</script>
<script type="text/javascript" src="js/smooth-scroll.js"></script>
</body>
</html>